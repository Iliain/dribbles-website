{
    "GRIDFIELD.ERRORINTRANSACTION": "Er is een fout opgetreden tijdens het ophalen van gegevens van de server.\nProbeer het later opnieuw.",
    "UserForms.ADDED_FIELD": "Nieuw veld toegevoegd",
    "UserForms.ADDED_OPTION": "Toegevoegde optie",
    "UserForms.ADDING_FIELD": "Nieuw veld toe te voegen",
    "UserForms.ADDING_OPTION": "Nieuwe optie toevoegen",
    "UserForms.ADDING_RULE": "Regel toevoegen",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Alle inzendingen zullen permanent worden verwijderd. Doorgaan?",
    "UserForms.ERROR_CREATING_FIELD": "Fout bij het maken optie",
    "UserForms.ERROR_CREATING_OPTION": "Fout bij het maken optie",
    "UserForms.HIDE_OPTIONS": "Verberg opties",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Verwijder optie",
    "UserForms.SHOW_OPTIONS": "Toon opties"
}