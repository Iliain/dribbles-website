{
    "GRIDFIELD.ERRORINTRANSACTION": "从服务器获取数据时发生错误\n请稍后再试。",
    "UserForms.ADDED_FIELD": "已添加新字段",
    "UserForms.ADDED_OPTION": "已添加选项",
    "UserForms.ADDING_FIELD": "正在添加新字段",
    "UserForms.ADDING_OPTION": "正在添加选项",
    "UserForms.ADDING_RULE": "正在添加规则",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "所有提交将被永久删除。要继续吗？",
    "UserForms.ERROR_CREATING_FIELD": "创建字段时发生错误",
    "UserForms.ERROR_CREATING_OPTION": "创建选项时发生错误",
    "UserForms.HIDE_OPTIONS": "隐藏选项",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "已删除选项",
    "UserForms.SHOW_OPTIONS": "显示选项"
}