{
    "GRIDFIELD.ERRORINTRANSACTION": "Errore durante la lettura dei dati dal server.\nPer favore riprovare più tardi.",
    "UserForms.ADDED_FIELD": "Aggiunto nuovo campo",
    "UserForms.ADDED_OPTION": "Aggiunta opzione",
    "UserForms.ADDING_FIELD": "In aggiunta di nuovo campo",
    "UserForms.ADDING_OPTION": "In aggiunta di opzione",
    "UserForms.ADDING_RULE": "In aggiunta di una regola",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Tutti gli invii saranno permanentemente rimossi. Continuare?",
    "UserForms.ERROR_CREATING_FIELD": "Errore durante la creazione del campo",
    "UserForms.ERROR_CREATING_OPTION": "Errore durante la creazione dell'opzione",
    "UserForms.HIDE_OPTIONS": "Nascondi opzioni",
    "UserForms.LEAVE_CONFIRMATION": "Hai modifiche non salvate!",
    "UserForms.REMOVED_OPTION": "Rimossa opzione",
    "UserForms.SHOW_OPTIONS": "Mostra opzioni"
}