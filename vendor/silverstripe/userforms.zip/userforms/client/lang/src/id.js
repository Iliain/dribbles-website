{
    "GRIDFIELD.ERRORINTRANSACTION": "An error occured while fetching data from the server\n Please try again later.",
    "UserForms.ADDED_FIELD": "Added new field",
    "UserForms.ADDED_OPTION": "Menambahkan Pilihan",
    "UserForms.ADDING_FIELD": "Adding new field",
    "UserForms.ADDING_OPTION": "Menambahkan Pilihan",
    "UserForms.ADDING_RULE": "Menambahkan Aturan",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Semua pengiriman akan dihapus secara permanen. Lanjutkan?",
    "UserForms.ERROR_CREATING_FIELD": "Error creating field",
    "UserForms.ERROR_CREATING_OPTION": "Error creating option",
    "UserForms.HIDE_OPTIONS": "Sembunyikan Pilihan",
    "UserForms.LEAVE_CONFIRMATION": "You have unsaved changes!",
    "UserForms.REMOVED_OPTION": "Removed option",
    "UserForms.SHOW_OPTIONS": "Menampilkan pilihan"
}