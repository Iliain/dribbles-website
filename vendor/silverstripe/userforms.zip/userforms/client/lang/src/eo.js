{
    "GRIDFIELD.ERRORINTRANSACTION": "Eraris venigante datumojn el la servilo.\nBonvolu reprovi poste.",
    "UserForms.ADDED_FIELD": "Aldonis novan kampon",
    "UserForms.ADDED_OPTION": "Aldonis agordon",
    "UserForms.ADDING_FIELD": "Aldonas novan kampon",
    "UserForms.ADDING_OPTION": "Aldonas agordon",
    "UserForms.ADDING_RULE": "Aldonas regulon",
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Ĉiuj sendaĵoj malaperos porĉiame. Ĉu daŭrigu?",
    "UserForms.ERROR_CREATING_FIELD": "Eraris kreante kampon",
    "UserForms.ERROR_CREATING_OPTION": "Eraris kreante agordon",
    "UserForms.HIDE_OPTIONS": "Kaŝi agordojn",
    "UserForms.LEAVE_CONFIRMATION": "Vi havas nekonservitajn ŝanĝojn",
    "UserForms.REMOVED_OPTION": "Forigis agordon",
    "UserForms.SHOW_OPTIONS": "Vidigi agordojn"
}